var class_grid_widget =
[
    [ "GridWidget", "class_grid_widget.html#abfc54e477706b66bd09f6f3c459fcfa4", null ],
    [ "actualPropagateEvent", "class_grid_widget.html#a9c57f1ca2311d3caa936a481fa7fbef0", null ],
    [ "actualRender", "class_grid_widget.html#ad2b2565b4ef8046f6886d09698567a18", null ],
    [ "actualResize", "class_grid_widget.html#a640c641444f6a5dae5a66af01d036777", null ],
    [ "actualSize", "class_grid_widget.html#a99ea6778447aae0b74170d613201b920", null ]
];