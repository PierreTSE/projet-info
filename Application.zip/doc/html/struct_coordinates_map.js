var struct_coordinates_map =
[
    [ "x", "struct_coordinates_map.html#a8f6bea9e92a85feabd9241cc95b7d6ea", null ],
    [ "y", "struct_coordinates_map.html#ad1d18b98c9e717166995ee58976a39ee", null ]
];