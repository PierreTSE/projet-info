var struct_zoom_event =
[
    [ "amount", "struct_zoom_event.html#a4f73dbfa13344cf5c4efa2ff591ce9cf", null ]
];