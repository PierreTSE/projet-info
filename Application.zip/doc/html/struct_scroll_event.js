var struct_scroll_event =
[
    [ "amount", "struct_scroll_event.html#a68165c193c13924b531fd3e9fd0738b7", null ]
];