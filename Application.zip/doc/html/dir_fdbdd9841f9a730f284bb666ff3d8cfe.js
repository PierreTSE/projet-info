var dir_fdbdd9841f9a730f284bb666ff3d8cfe =
[
    [ "Image.cpp", "_image_8cpp.html", "_image_8cpp" ],
    [ "Image.hpp", "_image_8hpp.html", [
      [ "Image", "class_image.html", "class_image" ]
    ] ],
    [ "TagList.hpp", "_tag_list_8hpp.html", "_tag_list_8hpp" ]
];