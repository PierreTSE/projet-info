var structdim__t =
[
    [ "x", "structdim__t.html#a4dbf33524feebe162d132357af785bbf", null ],
    [ "y", "structdim__t.html#a9d2b1acc3eecde57cb8e51acf52c4c0b", null ]
];