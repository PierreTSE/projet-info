var NAVTREE =
[
  [ "Image Tagger", "index.html", [
    [ "Classes", "annotated.html", [
      [ "Liste des classes", "annotated.html", "annotated_dup" ],
      [ "Index des classes", "classes.html", null ],
      [ "Hiérarchie des classes", "hierarchy.html", "hierarchy" ],
      [ "Membres de classe", "functions.html", [
        [ "Tout", "functions.html", "functions_dup" ],
        [ "Fonctions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ],
        [ "Définitions de type", "functions_type.html", null ],
        [ "Énumérations", "functions_enum.html", null ],
        [ "Valeurs énumérées", "functions_eval.html", null ],
        [ "Fonctions associées", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Fichiers", null, [
      [ "Liste des fichiers", "files.html", "files" ],
      [ "Membres de fichier", "globals.html", [
        [ "Tout", "globals.html", null ],
        [ "Fonctions", "globals_func.html", null ],
        [ "Définitions de type", "globals_type.html", null ],
        [ "Énumérations", "globals_enum.html", null ],
        [ "Valeurs énumérées", "globals_eval.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_application_8cpp.html",
"class_filtered_collection.html#a5370975bee6f470972aab31aa5921395",
"struct_un_click_event.html#a1466653f94232a3ae0b2fd9e981b7396ab099796116d046a517c2704122d60687"
];

var SYNCONMSG = 'cliquez pour désactiver la synchronisation du panel';
var SYNCOFFMSG = 'cliquez pour activer la synchronisation du panel';