var struct_move_event =
[
    [ "lastPos", "struct_move_event.html#ae5191df8cc511d06d66dda68095ac26a", null ]
];