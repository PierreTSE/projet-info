var class_application =
[
    [ "Application", "class_application.html#afa8cc05ce6b6092be5ecdfdae44e05f8", null ],
    [ "~Application", "class_application.html#a748bca84fefb9c12661cfaa2f623748d", null ],
    [ "execute", "class_application.html#a81d5b51e54511185c84ee300e752a85f", null ],
    [ "loadPossibleTags", "class_application.html#ad219c68e8f592d72df7150764cc71b91", null ],
    [ "save", "class_application.html#a45f71b866fbbae7dcf028a88b2af4cc7", null ],
    [ "saveAs", "class_application.html#ae22fc39c79b4efa62e80f548805410e5", null ],
    [ "savePossibleTags", "class_application.html#a8f9f948d5439efe526f3219d85b29d7f", null ]
];