var dir_659a8b1a10b8174f9cdda162b3bf05fc =
[
    [ "Collection.hpp", "_collection_8hpp.html", [
      [ "Collection", "class_collection.html", "class_collection" ]
    ] ],
    [ "CollectionIterator.hpp", "_collection_iterator_8hpp.html", [
      [ "IteratorBase", "class_iterator_base.html", "class_iterator_base" ],
      [ "CollectionIterator", "class_collection_iterator.html", "class_collection_iterator" ],
      [ "ConstIteratorBase", "class_const_iterator_base.html", "class_const_iterator_base" ],
      [ "ConstCollectionIterator", "class_const_collection_iterator.html", "class_const_collection_iterator" ]
    ] ],
    [ "CollectionPool.hpp", "_collection_pool_8hpp.html", [
      [ "PoolIterator", "class_pool_iterator.html", "class_pool_iterator" ],
      [ "ConstPoolIterator", "class_const_pool_iterator.html", "class_const_pool_iterator" ],
      [ "CollectionPool", "class_collection_pool.html", "class_collection_pool" ],
      [ "PoolIterator", "class_pool_iterator.html", "class_pool_iterator" ],
      [ "ConstPoolIterator", "class_const_pool_iterator.html", "class_const_pool_iterator" ]
    ] ],
    [ "FilteredCollection.hpp", "_filtered_collection_8hpp.html", [
      [ "FilteredIterator", "class_filtered_iterator.html", "class_filtered_iterator" ],
      [ "ConstFilteredIterator", "class_const_filtered_iterator.html", "class_const_filtered_iterator" ],
      [ "FilteredCollection", "class_filtered_collection.html", "class_filtered_collection" ],
      [ "FilteredIterator", "class_filtered_iterator.html", "class_filtered_iterator" ],
      [ "ConstFilteredIterator", "class_const_filtered_iterator.html", "class_const_filtered_iterator" ]
    ] ]
];