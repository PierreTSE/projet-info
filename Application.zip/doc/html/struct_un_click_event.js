var struct_un_click_event =
[
    [ "mouseButton_t", "struct_un_click_event.html#a1466653f94232a3ae0b2fd9e981b7396", [
      [ "LEFT", "struct_un_click_event.html#a1466653f94232a3ae0b2fd9e981b7396ab099796116d046a517c2704122d60687", null ],
      [ "MIDDLE", "struct_un_click_event.html#a1466653f94232a3ae0b2fd9e981b7396aab2152456bca75a0c657fecf0c9b8e85", null ],
      [ "RIGHT", "struct_un_click_event.html#a1466653f94232a3ae0b2fd9e981b7396a61dd82e27fe432ee0a87cc2e5719c274", null ]
    ] ],
    [ "type", "struct_un_click_event.html#a008b1e30b0105b789388788088707248", null ]
];