var struct_click_event =
[
    [ "mouseButton_t", "struct_click_event.html#a4006f96db41a3253ee212925df5374d2", [
      [ "LEFT", "struct_click_event.html#a4006f96db41a3253ee212925df5374d2ad970edc0479562a9120a1ff843b75497", null ],
      [ "MIDDLE", "struct_click_event.html#a4006f96db41a3253ee212925df5374d2a7f0c0040f3a86c9ce4f82cf24b38b560", null ],
      [ "RIGHT", "struct_click_event.html#a4006f96db41a3253ee212925df5374d2a930c56fd88f3faeb21b7aa0e1671f110", null ]
    ] ],
    [ "type", "struct_click_event.html#ad4b3e110510759224e813d3ad45736fd", null ]
];