var struct_event =
[
    [ "event", "struct_event.html#a2089dfced3ff2ece7102a439de13971c", null ],
    [ "pos", "struct_event.html#a405730c60365283ce01c2399e6f664a8", null ]
];