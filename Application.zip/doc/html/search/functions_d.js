var searchData=
[
  ['render',['render',['../class_widget.html#a2516fd56cac645cb3aacef37937c49d3',1,'Widget']]],
  ['reserve',['reserve',['../class_collection_pool.html#a06334969f57ca768241af598f03e8de1',1,'CollectionPool']]],
  ['resize',['resize',['../class_widget.html#a0809c3a396f9d1cedb1446d7b0750ef2',1,'Widget']]]
];
