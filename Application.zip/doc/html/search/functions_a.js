var searchData=
[
  ['main',['main',['../main_8cpp.html#adc4096c0dfd003425c219daa30db4e1e',1,'main.cpp']]],
  ['manageevents',['manageEvents',['../class_window_widget.html#a541a8f556d865da798786e2601cf031e',1,'WindowWidget']]],
  ['max_5fsize',['max_size',['../class_collection_pool.html#a333a1edf4c98229f47b698463baf0324',1,'CollectionPool']]],
  ['menubarwidget',['MenuBarWidget',['../class_menu_bar_widget.html#a091cd67b87a4b34d08b97163f7f48257',1,'MenuBarWidget']]]
];
