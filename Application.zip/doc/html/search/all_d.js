var searchData=
[
  ['quote',['QUOTE',['../_image_8cpp.html#a5d74787dedbc4e11c1ab15bf487e61f8ada126905189f15af6d475cc45f0cb2b2',1,'Image.cpp']]]
];
