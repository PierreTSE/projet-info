var searchData=
[
  ['layoutwidget',['LayoutWidget',['../class_layout_widget.html#ab27c4c576f3a9351b4efdde91433b7a1',1,'LayoutWidget']]],
  ['listwidget',['ListWidget',['../class_list_widget.html#ac785b259033fc933d977e7584f8541b2',1,'ListWidget::ListWidget(const std::vector&lt; std::string &gt; &amp;texts, bool column=false, int fontSize=23, const dim_t &amp;size={ 0, 0 })'],['../class_list_widget.html#a700e9c7fd4880f99c373870615fcc4e6',1,'ListWidget::ListWidget(const ListWidget &amp;other)']]],
  ['loadimage',['loadImage',['../class_image.html#ad6c6fc59aaffc9c101047e8ef32abc9d',1,'Image']]],
  ['loadpossibletags',['loadPossibleTags',['../class_application.html#ad219c68e8f592d72df7150764cc71b91',1,'Application']]]
];
