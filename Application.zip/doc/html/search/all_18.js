var searchData=
[
  ['x',['x',['../structdim__t.html#a4dbf33524feebe162d132357af785bbf',1,'dim_t::x()'],['../struct_coordinates_map.html#a8f6bea9e92a85feabd9241cc95b7d6ea',1,'CoordinatesMap::x()']]],
  ['xln',['xln',['../namespacecimg__library__suffixed_1_1cimg.html#a33280187782b500494b92832fc13e339',1,'cimg_library_suffixed::cimg']]],
  ['xyytorgb',['xyYtoRGB',['../structcimg__library__suffixed_1_1_c_img.html#a4120b423486997772fc643dc6597381e',1,'cimg_library_suffixed::CImg']]],
  ['xyytoxyz',['xyYtoXYZ',['../structcimg__library__suffixed_1_1_c_img.html#a051b8b41d46276207243d171a44acb52',1,'cimg_library_suffixed::CImg']]],
  ['xyztolab',['XYZtoLab',['../structcimg__library__suffixed_1_1_c_img.html#a248e5f2202f89f21769c08e35a38c1e9',1,'cimg_library_suffixed::CImg']]],
  ['xyztorgb',['XYZtoRGB',['../structcimg__library__suffixed_1_1_c_img.html#a192bacbc98405263a4576c2c56209295',1,'cimg_library_suffixed::CImg']]],
  ['xyztoxyy',['XYZtoxyY',['../structcimg__library__suffixed_1_1_c_img.html#a02b07a06bfbca6ca84b97f052d9e2bfc',1,'cimg_library_suffixed::CImg']]]
];
