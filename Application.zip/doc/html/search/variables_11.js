var searchData=
[
  ['variable_5fdef',['variable_def',['../structcimg__library__suffixed_1_1_c_img_1_1__cimg__math__parser.html#afc1549a689744825235a5a7cb5648cfb',1,'cimg_library_suffixed::CImg::_cimg_math_parser']]],
  ['variable_5fpos',['variable_pos',['../structcimg__library__suffixed_1_1_c_img_1_1__cimg__math__parser.html#adf916aa7f24f400a959bc9844587f8f1',1,'cimg_library_suffixed::CImg::_cimg_math_parser']]]
];
