var searchData=
[
  ['allocator_5ftype',['allocator_type',['../class_collection.html#ac7974b0b552f0a94065aadc48ae53397',1,'Collection::allocator_type()'],['../class_collection_pool.html#a2334b5af86ff5008ec9ad1ff2ea17e19',1,'CollectionPool::allocator_type()'],['../class_filtered_collection.html#a89348fde51fe48c6528e5ac5abe72c6d',1,'FilteredCollection::allocator_type()']]]
];
