var searchData=
[
  ['image',['Image',['../class_image.html#a5502e928122744be1d3b89648298e162',1,'Image::Image()=default'],['../class_image.html#a28c9333c57d99129b5350f9df93f22ea',1,'Image::Image(const std::experimental::filesystem::path &amp;p, std::unique_ptr&lt; cimg_library::CImg&lt; unsigned char &gt;&gt; cimgPtr=nullptr, const TagList &amp;t={})']]],
  ['imagewidget',['ImageWidget',['../class_image_widget.html#a966378e502da16bab8c1596ed365e8d6',1,'ImageWidget']]],
  ['importfromdirectory',['importFromDirectory',['../_utilities_8cpp.html#a5ce6411f7ab365cdf958f8f16e773d05',1,'importFromDirectory(const fs::path &amp;directoryPath, CollectionPool&lt; Image &gt; &amp;collectionPool):&#160;Utilities.cpp'],['../_utilities_8hpp.html#a41b172caaf9dd1e2d0ba53b75a217d7c',1,'importFromDirectory(const std::experimental::filesystem::path &amp;directoryPath, CollectionPool&lt; Image &gt; &amp;collectionPool):&#160;Utilities.hpp']]],
  ['is_5fopen',['is_open',['../class_window_widget.html#a556741682ef738cc417f707cc288d7ec',1,'WindowWidget']]],
  ['iscolored',['isColored',['../class_button_widget.html#a5239cdc7bf6ea60722aa0620611be239',1,'ButtonWidget']]],
  ['isinside',['isInside',['../class_widget.html#ae5b0e7b391d855a3f75f166bb20253a8',1,'Widget']]],
  ['iso8859_5f1toutf8',['ISO8859_1toUTF8',['../_utilities_8cpp.html#ad57af8b864a883b661328ca89df5b32b',1,'ISO8859_1toUTF8(const std::string &amp;str):&#160;Utilities.cpp'],['../_utilities_8hpp.html#ad57af8b864a883b661328ca89df5b32b',1,'ISO8859_1toUTF8(const std::string &amp;str):&#160;Utilities.cpp']]],
  ['isselected',['isSelected',['../class_image.html#aa0342748b3c981c6c06e0bf82a397895',1,'Image']]],
  ['iteratorbase',['IteratorBase',['../class_iterator_base.html#a6d1810e7a0a84574bb61d78bb99d96bb',1,'IteratorBase']]]
];
