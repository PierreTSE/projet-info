var searchData=
[
  ['std_5ffopen',['std_fopen',['../_c_img_8h.html#adc8f2783d2e1e2b902b58eb1ddd6e2e4',1,'CImg.h']]]
];
