var searchData=
[
  ['display',['display',['../class_window_widget.html#aaeb6c16306f82469d443182594a8ef8e',1,'WindowWidget']]]
];
