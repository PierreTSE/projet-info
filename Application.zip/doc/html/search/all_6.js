var searchData=
[
  ['getbackgroundcolor',['getBackgroundColor',['../class_button_widget.html#aa7f6cc7186fca19b23c68ba71a0e1cf9',1,'ButtonWidget']]],
  ['getimage',['getImage',['../class_image_widget.html#a63d0e429c61daa47462c20c805762709',1,'ImageWidget']]],
  ['getimgptr',['getImgPtr',['../class_image.html#a657a199518956ca160b1100c2147b41d',1,'Image::getImgPtr()'],['../class_image.html#ae9c33ef7fcb6c7fc358ed05c64472ecd',1,'Image::getImgPtr() const']]],
  ['getlength',['getLength',['../class_list_widget.html#afc145e63065556e4c2f9071a08a6c9b8',1,'ListWidget']]],
  ['getopenfilename',['getOpenFileName',['../_file_dialog_8hpp.html#a2e66e4c74906951726d32246d1b77e9a',1,'FileDialog.hpp']]],
  ['getpath',['getPath',['../class_image.html#a2b77063d4c4f0ac499ecd8442f490d1e',1,'Image::getPath()'],['../class_image.html#af497432c080fe6bbbcf54c34f17ecb7a',1,'Image::getPath() const']]],
  ['getsavefilename',['getSaveFileName',['../_file_dialog_8hpp.html#a2781b8e73494c1ffed0cbf1060545c8f',1,'FileDialog.hpp']]],
  ['gettaglist',['getTagList',['../class_image.html#ab9615cd8d9ea8a1bcc844c3d1d8c0e47',1,'Image::getTagList()'],['../class_image.html#a0defad17dd6f06994319e842e0f910fe',1,'Image::getTagList() const']]],
  ['gettextfrombox',['getTextFromBox',['../_text_box_8hpp.html#aeff834ba7c5b4e30fd819bcafefb9127',1,'TextBox.hpp']]],
  ['getwindow',['getWindow',['../class_widget.html#aadb11a1dfa9f73aa5379914a37b8b5fd',1,'Widget::getWindow()'],['../class_widget.html#a1d36bcdc5a64ead5403be88654a5559f',1,'Widget::getWindow() const'],['../class_window_widget.html#acb335c0d4fcbe9a46fa60a1b245ff765',1,'WindowWidget::getWindow() override'],['../class_window_widget.html#a0272c67c6352252523ec0f760834e4f0',1,'WindowWidget::getWindow() const override']]],
  ['gridwidget',['GridWidget',['../class_grid_widget.html',1,'GridWidget'],['../class_grid_widget.html#abfc54e477706b66bd09f6f3c459fcfa4',1,'GridWidget::GridWidget()']]],
  ['gridwidget_2ecpp',['GridWidget.cpp',['../_grid_widget_8cpp.html',1,'']]],
  ['gridwidget_2ehpp',['GridWidget.hpp',['../_grid_widget_8hpp.html',1,'']]]
];
