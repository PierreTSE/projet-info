var searchData=
[
  ['path_5fbackslash',['PATH_BACKSLASH',['../_image_8cpp.html#a5d74787dedbc4e11c1ab15bf487e61f8a62791d7083fb34365a1183b0f19f4e16',1,'Image.cpp']]],
  ['path_5fname',['PATH_NAME',['../_image_8cpp.html#a5d74787dedbc4e11c1ab15bf487e61f8a3e6c37df8365b5b5493470a04b8c30a2',1,'Image.cpp']]]
];
