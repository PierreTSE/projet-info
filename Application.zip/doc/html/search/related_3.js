var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../class_image.html#a2d6d264c420ab6eecf731ead84a8eb99',1,'Image']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../class_image.html#ab5811a3704784bbb57375abbbacfe4fd',1,'Image']]]
];
