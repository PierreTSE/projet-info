var searchData=
[
  ['tag_5fbackslash',['TAG_BACKSLASH',['../_image_8cpp.html#a5d74787dedbc4e11c1ab15bf487e61f8a832062c2e04a5369310ee549901c66ac',1,'Image.cpp']]],
  ['tag_5fname',['TAG_NAME',['../_image_8cpp.html#a5d74787dedbc4e11c1ab15bf487e61f8add0139f90f702159f2a1f96573fb5b29',1,'Image.cpp']]]
];
