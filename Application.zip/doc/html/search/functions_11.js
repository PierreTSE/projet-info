var searchData=
[
  ['windowwidget',['WindowWidget',['../class_window_widget.html#a04db7bfbafe9a5fd603ddaa5b838ded5',1,'WindowWidget']]]
];
