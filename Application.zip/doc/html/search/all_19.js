var searchData=
[
  ['y',['Y',['../structcimg__library__suffixed_1_1_c_img_list.html#aeb5664694c867337058da90628ad710f',1,'cimg_library_suffixed::CImgList::Y()'],['../structdim__t.html#a9d2b1acc3eecde57cb8e51acf52c4c0b',1,'dim_t::y()'],['../struct_coordinates_map.html#ad1d18b98c9e717166995ee58976a39ee',1,'CoordinatesMap::y()']]],
  ['ycbcrtorgb',['YCbCrtoRGB',['../structcimg__library__suffixed_1_1_c_img.html#a00f803407df18a117adca1f75abd9aed',1,'cimg_library_suffixed::CImg']]],
  ['yuvtorgb',['YUVtoRGB',['../structcimg__library__suffixed_1_1_c_img.html#ab482b000aa2416bf063cfb4709b27e28',1,'cimg_library_suffixed::CImg']]]
];
