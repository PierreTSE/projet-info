var searchData=
[
  ['iteratorbase_3c_20t_20_3e',['IteratorBase&lt; T &gt;',['../class_collection_iterator.html#a6076dfcb85a3a7cb903b827fa821fe54',1,'CollectionIterator']]]
];
