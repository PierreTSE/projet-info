var indexSectionsWithContent =
{
  0: "abcdefghilmopqrstuvwxyz~",
  1: "abcdefgilmpstuwz",
  2: "abcefgilmstuw",
  3: "abcdefghilmoprstuw~",
  4: "aelptxy",
  5: "acdiprstv",
  6: "ms",
  7: "eilmopqrst",
  8: "cfio"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "related"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Définitions de type",
  6: "Énumérations",
  7: "Valeurs énumérées",
  8: "Amis"
};

