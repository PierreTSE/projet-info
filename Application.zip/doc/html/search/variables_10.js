var searchData=
[
  ['user_5fmacro',['user_macro',['../structcimg__library__suffixed_1_1_c_img_1_1__cimg__math__parser.html#adb28d6dfa1569c5c1b991efb2ab113bb',1,'cimg_library_suffixed::CImg::_cimg_math_parser']]]
];
