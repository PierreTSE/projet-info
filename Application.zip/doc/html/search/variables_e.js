var searchData=
[
  ['s_5fop',['s_op',['../structcimg__library__suffixed_1_1_c_img_1_1__cimg__math__parser.html#a203276ce7308b0bb54fddf16bf0aa9e5',1,'cimg_library_suffixed::CImg::_cimg_math_parser']]],
  ['ss_5fop',['ss_op',['../structcimg__library__suffixed_1_1_c_img_1_1__cimg__math__parser.html#a405dc98771a9120126075b7389993761',1,'cimg_library_suffixed::CImg::_cimg_math_parser']]]
];
