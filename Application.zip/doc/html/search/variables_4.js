var searchData=
[
  ['title',['title',['../structfile__filter.html#a5bb33083d08fd4d3f991598d02b8af4d',1,'file_filter']]],
  ['type',['type',['../struct_click_event.html#ad4b3e110510759224e813d3ad45736fd',1,'ClickEvent::type()'],['../struct_un_click_event.html#a008b1e30b0105b789388788088707248',1,'UnClickEvent::type()']]]
];
