var searchData=
[
  ['z',['Z',['../structcimg__library__suffixed_1_1_c_img_list.html#a5fbab9a9b8a745a7bbccc6887f7b98bf',1,'cimg_library_suffixed::CImgList']]],
  ['zoomevent',['ZoomEvent',['../struct_zoom_event.html',1,'']]]
];
