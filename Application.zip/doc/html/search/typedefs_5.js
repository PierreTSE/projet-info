var searchData=
[
  ['reference',['reference',['../class_collection.html#abbc291771b11c48cd2f297a0d9fe0449',1,'Collection::reference()'],['../class_collection_iterator.html#aac15417aa7a67fdfb86b8bad1b4d5ddf',1,'CollectionIterator::reference()'],['../class_const_collection_iterator.html#a216f7bd76fb369ad1fb46527824da9c8',1,'ConstCollectionIterator::reference()'],['../class_collection_pool.html#a12dd127db0342d4b694d857f6c77ad90',1,'CollectionPool::reference()'],['../class_filtered_collection.html#afc4e47695287b6bac73899ab5bcfdf6e',1,'FilteredCollection::reference()']]]
];
