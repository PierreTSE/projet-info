var searchData=
[
  ['amount',['amount',['../struct_scroll_event.html#a68165c193c13924b531fd3e9fd0738b7',1,'ScrollEvent::amount()'],['../struct_zoom_event.html#a4f73dbfa13344cf5c4efa2ff591ce9cf',1,'ZoomEvent::amount()']]]
];
