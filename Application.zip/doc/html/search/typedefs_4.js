var searchData=
[
  ['pointer',['pointer',['../class_collection.html#a9a5b5d9b389c113364d527900c745efb',1,'Collection::pointer()'],['../class_collection_iterator.html#aff846a9c86022d66a7eb10e3623a0ba0',1,'CollectionIterator::pointer()'],['../class_const_collection_iterator.html#a9297f2ca1f4bb6dd1e393c2900f60ed9',1,'ConstCollectionIterator::pointer()'],['../class_collection_pool.html#a3bfec6c487a93170866fde4b57a85b21',1,'CollectionPool::pointer()'],['../class_filtered_collection.html#a0c78e02c35e4b712b945a0e5c6b9a14a',1,'FilteredCollection::pointer()']]]
];
