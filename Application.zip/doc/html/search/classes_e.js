var searchData=
[
  ['widget',['Widget',['../class_widget.html',1,'']]],
  ['windowwidget',['WindowWidget',['../class_window_widget.html',1,'']]]
];
