var searchData=
[
  ['filteredcollection',['FilteredCollection',['../class_filtered_collection.html#a78c712f40560a66d05ce97755d6c0749',1,'FilteredCollection::FilteredCollection(Collection&lt; T &gt; &amp;c, const filtre_t &amp;f)'],['../class_filtered_collection.html#aba5f5ccfb98f0eaf043035860f0c3499',1,'FilteredCollection::FilteredCollection(const Collection&lt; T &gt; &amp;c, const filtre_t &amp;f)']]],
  ['filterediterator',['FilteredIterator',['../class_filtered_iterator.html#a7d4de1fd089da50804d41dcf387b5e4e',1,'FilteredIterator']]]
];
