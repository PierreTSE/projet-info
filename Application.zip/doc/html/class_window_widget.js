var class_window_widget =
[
    [ "WindowWidget", "class_window_widget.html#a04db7bfbafe9a5fd603ddaa5b838ded5", null ],
    [ "actualPropagateEvent", "class_window_widget.html#a78dedcff8ae2df9a9f86fc0ba17a1998", null ],
    [ "actualRender", "class_window_widget.html#aaec9f66e42abae3db2c28b4d153f4102", null ],
    [ "actualResize", "class_window_widget.html#a89a68a5d4dc9fd5da10ac75c1121a453", null ],
    [ "actualSize", "class_window_widget.html#ab7ed87b677d814d58e7f5aebefa7df70", null ],
    [ "close", "class_window_widget.html#abdbf63bb8a663c46bfdd2c117aa55e4d", null ],
    [ "display", "class_window_widget.html#aaeb6c16306f82469d443182594a8ef8e", null ],
    [ "getWindow", "class_window_widget.html#acb335c0d4fcbe9a46fa60a1b245ff765", null ],
    [ "getWindow", "class_window_widget.html#a0272c67c6352252523ec0f760834e4f0", null ],
    [ "is_open", "class_window_widget.html#a556741682ef738cc417f707cc288d7ec", null ],
    [ "manageEvents", "class_window_widget.html#a541a8f556d865da798786e2601cf031e", null ],
    [ "setCallBack", "class_window_widget.html#a7bee581e186647a29667a09eaab61035", null ],
    [ "setContent", "class_window_widget.html#a4d1f999183262930b2472bcd212644aa", null ],
    [ "spawnRightClickMenu", "class_window_widget.html#a010f6706afa1a7221312e1b9d854731a", null ]
];