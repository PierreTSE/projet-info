var class_pool_iterator =
[
    [ "PoolIterator", "class_pool_iterator.html#a5c4bd22679d557a14326b018850874bb", null ],
    [ "clone", "class_pool_iterator.html#ae39cdb4bbb84e88cf0d9009e7bdae586", null ],
    [ "equal", "class_pool_iterator.html#adbbef39e72972414b1bbb6d6bb885bb1", null ],
    [ "operator*", "class_pool_iterator.html#a3acdd751b297473d78eedb7422c7a66c", null ],
    [ "operator*", "class_pool_iterator.html#ab8a7e0669bfd1cd4335ca726bba77127", null ],
    [ "operator++", "class_pool_iterator.html#a0da86ab88d60973aee45e6a51a929138", null ],
    [ "operator--", "class_pool_iterator.html#aa1f588a47b0c11d6e064e34b129337ae", null ],
    [ "operator->", "class_pool_iterator.html#ae2893041831d8c29f222af7fe184fe09", null ],
    [ "operator->", "class_pool_iterator.html#a228d6ee24cd015a7312fa9f76244994c", null ]
];