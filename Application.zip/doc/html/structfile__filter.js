var structfile__filter =
[
    [ "pattern", "structfile__filter.html#a66658e1ec5a2c6a586d9855f12779a04", null ],
    [ "title", "structfile__filter.html#a5bb33083d08fd4d3f991598d02b8af4d", null ]
];