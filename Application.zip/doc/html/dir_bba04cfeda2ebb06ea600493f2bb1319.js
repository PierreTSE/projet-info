var dir_bba04cfeda2ebb06ea600493f2bb1319 =
[
    [ "ButtonWidget.cpp", "_button_widget_8cpp.html", null ],
    [ "ButtonWidget.hpp", "_button_widget_8hpp.html", [
      [ "ButtonWidget", "class_button_widget.html", "class_button_widget" ]
    ] ],
    [ "Events.hpp", "_events_8hpp.html", "_events_8hpp" ],
    [ "GridWidget.cpp", "_grid_widget_8cpp.html", null ],
    [ "GridWidget.hpp", "_grid_widget_8hpp.html", [
      [ "GridWidget", "class_grid_widget.html", "class_grid_widget" ]
    ] ],
    [ "ImageWidget.cpp", "_image_widget_8cpp.html", null ],
    [ "ImageWidget.hpp", "_image_widget_8hpp.html", [
      [ "ImageWidget", "class_image_widget.html", "class_image_widget" ]
    ] ],
    [ "LayoutWidget.cpp", "_layout_widget_8cpp.html", null ],
    [ "LayoutWidget.hpp", "_layout_widget_8hpp.html", [
      [ "LayoutWidget", "class_layout_widget.html", "class_layout_widget" ]
    ] ],
    [ "ListWidget.cpp", "_list_widget_8cpp.html", null ],
    [ "ListWidget.hpp", "_list_widget_8hpp.html", [
      [ "CoordinatesMap", "struct_coordinates_map.html", "struct_coordinates_map" ],
      [ "ListWidget", "class_list_widget.html", "class_list_widget" ]
    ] ],
    [ "MenuBarWidget.cpp", "_menu_bar_widget_8cpp.html", null ],
    [ "MenuBarWidget.hpp", "_menu_bar_widget_8hpp.html", [
      [ "MenuBarWidget", "class_menu_bar_widget.html", "class_menu_bar_widget" ]
    ] ],
    [ "ScrollWidget.cpp", "_scroll_widget_8cpp.html", null ],
    [ "ScrollWidget.hpp", "_scroll_widget_8hpp.html", [
      [ "ScrollWidget", "class_scroll_widget.html", "class_scroll_widget" ]
    ] ],
    [ "TagSelector.cpp", "_tag_selector_8cpp.html", null ],
    [ "TagSelector.hpp", "_tag_selector_8hpp.html", [
      [ "TagSelector", "class_tag_selector.html", "class_tag_selector" ]
    ] ],
    [ "TagSetterWidget.cpp", "_tag_setter_widget_8cpp.html", null ],
    [ "TagSetterWidget.hpp", "_tag_setter_widget_8hpp.html", [
      [ "TagSetterWidget", "class_tag_setter_widget.html", "class_tag_setter_widget" ]
    ] ],
    [ "TagViewerWidget.cpp", "_tag_viewer_widget_8cpp.html", null ],
    [ "TagViewerWidget.hpp", "_tag_viewer_widget_8hpp.html", [
      [ "TagViewerWidget", "class_tag_viewer_widget.html", "class_tag_viewer_widget" ]
    ] ],
    [ "Widget.cpp", "_widget_8cpp.html", null ],
    [ "Widget.hpp", "_widget_8hpp.html", [
      [ "Widget", "class_widget.html", "class_widget" ]
    ] ],
    [ "WindowWidget.cpp", "_window_widget_8cpp.html", null ],
    [ "WindowWidget.hpp", "_window_widget_8hpp.html", [
      [ "WindowWidget", "class_window_widget.html", "class_window_widget" ]
    ] ]
];